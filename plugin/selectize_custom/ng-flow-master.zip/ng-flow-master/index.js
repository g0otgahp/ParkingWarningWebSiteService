/* for module loading using webpack or similar package bundlers */
window.Flow = require('./dist/ng-flow-standalone');
module.exports = 'flow';
